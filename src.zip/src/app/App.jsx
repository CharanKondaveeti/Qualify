import React, { Suspense } from 'react';
import { createBrowserRouter, Navigate, RouterProvider, useParams } from 'react-router-dom';
import '../styles/app.css';
import { QueryClientProvider } from '@tanstack/react-query';
import { Provider } from 'react-redux';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { ToastContainer } from 'react-toastify';
import { store } from '../store/index';
import queryClient from '../lib/queryClient';
import LandingPage from '../features/auth/pages/LandingPage';
import AdminAuthPage from '../features/auth/pages/AdminAuthPage';
import PasswordRecoveryPage from '../features/auth/pages/PasswordRecoveryPage';
import DashboardPage from '../features/admin/pages/DashboardPage';
import AdminStartPage from '../features/admin/pages/AdminStartPage';
import AdminRouteGuard from '../features/admin/components/AdminRouteGuard';
import CalendarPage from '../features/admin/pages/CalendarPage';
import ExamsPage from '../features/admin/pages/ExamsPage';
import CreateExamPage from '../features/admin/pages/CreateExamPage';
import ExamDetailsPage from '../features/admin/pages/ExamDetailsPage';
import QuestionBankPage from '../features/admin/pages/QuestionBankPage';
import SettingsPage from '../features/admin/pages/SettingsPage';
import InstitutionsPage from '../features/admin/pages/InstitutionsPage';
import TeamPage from '../features/admin/pages/TeamPage';
import ReportsPage from '../features/admin/pages/ReportsPage';
import ApplyInstitutionPage from '../features/institutions/pages/ApplyInstitutionPage';
import AcceptInvitePage from '../features/institutions/pages/AcceptInvitePage';
import InstitutionGate from '../features/institutions/components/InstitutionGate';
import ExamPage from '../features/student/pages/ExamPage';
import ResultsPage from '../features/student/pages/ResultsPage';
import ExamRegistrationPage from '../features/student/pages/ExamRegistrationPage';

function LegacyExamRedirect() { const { examId } = useParams(); return <Navigate to={`/admin/exams/${examId}`} replace />; }
const restricted = (permission, element) =>
  <AdminRouteGuard permission={permission}>{element}</AdminRouteGuard>;
const router = createBrowserRouter([
  { path: '/', element: <LandingPage /> },
  { path: '/login', element: <LandingPage /> },
  // Never alter existing student URLs or private access tokens.
  { path: '/exams/:examId/student/:studentId', element: <ExamPage /> },
  { path: '/register/exam/:examId', element: <ExamRegistrationPage /> },
  { path: '/results/:studentId', element: <ResultsPage /> },
  { path: '/admin-login', element: <AdminAuthPage /> },
  { path: '/forgot-password', element: <PasswordRecoveryPage key="request" /> },
  { path: '/reset-password', element: <PasswordRecoveryPage key="reset" reset /> },
  // Institution application / invite acceptance use the ORIGINAL auth card design.
  { path: '/institution/apply', element: <InstitutionGate workspaceOnly><ApplyInstitutionPage /></InstitutionGate> },
  { path: '/institution/invite', element: <InstitutionGate><AcceptInvitePage /></InstitutionGate> },
  // Old institutional workspace URLs redirect to the single original dashboard.
  { path: '/platform', element: <Navigate to="/admin/institutions" replace /> },
  { path: '/institution', element: <Navigate to="/admin" replace /> },
  { path: '/institution/exams', element: <Navigate to="/admin/exams" replace /> },
  { path: '/institution/exams/:examId', element: <LegacyExamRedirect /> },
  { path: '/institution/question-bank', element: <Navigate to="/admin/question-bank" replace /> },
  { path: '/admin', element: <DashboardPage />, children: [
    { index: true, element: <AdminStartPage /> },
    { path: 'exams', element: restricted('exams', <ExamsPage />) },
    { path: 'calendar', element: restricted('exams', <CalendarPage />) },
    { path: 'reports', element: restricted('exams', <ReportsPage />) },
    { path: 'question-bank', element: restricted('exams', <QuestionBankPage />) },
    { path: 'exam/create', element: restricted('exams', <CreateExamPage />) },
    { path: 'exams/create', element: restricted('exams', <CreateExamPage />) },
    { path: 'exams/:examId', element: restricted('exams', <ExamDetailsPage />) },
    { path: 'team', element: restricted('institutionAdmin', <TeamPage />) },
    { path: 'institutions', element: restricted('platformOwner', <InstitutionsPage />) },
    { path: 'settings', element: <SettingsPage /> },
  ] },
  { path: '*', element: <div className="portal-message"><h1>Page not found</h1><a href="/">Return to Qualify</a></div> },
]);

export default function App() {
  return <Provider store={store}><QueryClientProvider client={queryClient}>
    <div className="app-container"><Suspense fallback={<div className="portal-message">Loading Qualify…</div>}>
      <RouterProvider router={router} /></Suspense><ToastContainer position="top-right" autoClose={3000} />
    </div>{import.meta.env.DEV && <ReactQueryDevtools initialIsOpen={false} />}
  </QueryClientProvider></Provider>;
}
