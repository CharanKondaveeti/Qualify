import { useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import supabase, { isDemo } from '../../../lib/supabase';
import { getInstitutionAccess } from '../../../services/institutionService';
import PendingStaffInviteDialog from './PendingStaffInviteDialog';

export default function InstitutionGate({ role = 'any', workspaceOnly = false, children }) {
  const [result, setResult] = useState(null);
  const location = useLocation();
  useEffect(() => {
    // Institutional registration and invitations require real Supabase RPCs.
    // The local demo client deliberately has no .rpc() implementation.
    // Demo mode persists across navigation, so clear it and reload the real client.
    if (isDemo) {
      sessionStorage.removeItem('qualify-demo');
      window.location.replace(location.pathname + location.search + location.hash);
      return;
    }
    let active = true;
    (async () => {
      const { data: { user }, error } = await supabase.auth.getUser();
      if (!user || error) { if (active) setResult({ state: 'login' }); return; }
      try {
        const access = await getInstitutionAccess();
        if (active) setResult({ state: 'ready', access, user });
      } catch (err) {
        if (active) setResult({ state: 'error', message: err.message });
      }
    })();
    return () => { active = false; };
  }, [location.pathname, location.search, location.hash]);
  if (isDemo) return <div className="portal-message">Switching to real Supabase for institution access…</div>;
  if (!result) return <div className="portal-message">Checking your account…</div>;
  if (result.state === 'login') {
    const next = location.pathname === '/institution/invite'
      ? `?next=${encodeURIComponent(location.pathname + location.search)}` : '';
    return <Navigate to={`/admin-login${next}`} replace />;
  }
  if (result.state === 'error') return <div className="portal-message" role="alert">{result.message}<p>Confirm Phase 1 SQL was installed before Phase 2.</p></div>;
  if (workspaceOnly && result.access.platform_owner) return <Navigate to="/admin/institutions" replace />;
  if (workspaceOnly && (result.access.institutions || []).some(i =>
    i.member_status === 'active' && i.institution_status === 'active'
  )) return <Navigate to="/admin/exams" replace />;
  if (role === 'owner' && !result.access.platform_owner) return <Navigate to="/institution" replace />;
  if (role === 'member' && !result.access.platform_owner && !(result.access.institutions || []).some(i =>
    i.member_status === 'active' && i.institution_status === 'active')) return <Navigate to="/institution/apply" replace />;
  return <>{location.pathname !== '/institution/invite' && <PendingStaffInviteDialog />}{children}</>;
}
