import { useState } from 'react';
import { Link } from 'react-router-dom';
import { isDemo, isDemoAvailable } from '../../../lib/supabase';
import '../styles/landing-page.css';
export default function LandingPage() {
  const [examLink, setExamLink] = useState('');
  const [error, setError] = useState('');
  function join(e) {
    e.preventDefault();
    try {
      const url = new URL(examLink, window.location.origin);
      if (url.origin !== window.location.origin || !/^\/(register\/exam\/[^/]+|exams\/[^/]+\/student\/[^/]+)$/.test(url.pathname)) throw new Error();
      // Preserve private access tokens in the query string.
      window.location.assign(url.pathname + url.search + url.hash);
    } catch { setError('Paste the registration or exam link provided by your instructor.'); }
  }
  return <div className="loginpage-container">
    <div className="loginpage-header"><div className="loginpage-logo"><h1 className="loginpage-logo-text">QUALIFY</h1></div><span className="eyebrow">YOUR NEXT CHAPTER STARTS HERE</span><h1 className="loginpage-title">A focused space for every exam.</h1><p className="loginpage-subtitle">Prepare with purpose. Assess with confidence.</p></div>
    <div className="loginpage-cards">
      <section className="loginpage-card loginpage-admin-card"><div className="portal-card-number">01 / ADMINISTRATORS</div><h2>Manage examinations</h2><p>Create assessments, organize questions, and follow your students' progress.</p><Link to="/admin-login" className="loginpage-button loginpage-admin-button">Access Exam Panel →</Link><Link className="demo-link" to="/institution/apply">Register your institution →</Link>{isDemoAvailable && <a className="demo-link" href="/admin/exams?demo=1">Explore live demo</a>}</section>
      <section className="loginpage-card loginpage-student-card"><div className="portal-card-number">02 / STUDENTS</div><h2>Ready to qualify?</h2><p>Use your instructor's exam link to register or continue your assessment.</p><form onSubmit={join}><label className="sr-only" htmlFor="exam-link">Exam link</label><input id="exam-link" className="portal-input" value={examLink} onChange={e => setExamLink(e.target.value)} placeholder="Paste your exam link" required /><button className="loginpage-button loginpage-student-button">Continue to exam →</button></form>{error && <p role="alert">{error}</p>}{isDemoAvailable && <a className="demo-link" href="/exams/demo-active/student/demo-student?demo=1">Try a sample exam</a>}</section>
    </div>
  </div>;
}
