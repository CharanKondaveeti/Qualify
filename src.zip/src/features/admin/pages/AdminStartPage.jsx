import { Navigate } from 'react-router-dom';
import { useAdminWorkspace } from '../context/AdminWorkspaceContext';
export default function AdminStartPage() {
  const { canUseExams, isOwner } = useAdminWorkspace();
  return <Navigate to={canUseExams ? '/admin/exams' : isOwner ? '/admin/institutions' : '/institution/apply'} replace />;
}
