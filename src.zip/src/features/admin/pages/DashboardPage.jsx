import {
  createElement,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  FiBook,
  FiCalendar,
  FiSettings,
  FiLogOut,
  FiMenu,
  FiLayers,
  FiUsers,
  FiGrid,
  FiBarChart2,
} from "react-icons/fi";
import supabase, { isDemo } from "../../../lib/supabase";
import {
  getInstitutionAccess,
  getInstitutionBranding,
  listPlatformInstitutions,
} from "../../../services/institutionService";
import InstitutionBrand from "../../../shared/components/InstitutionBrand";
import PendingStaffInviteDialog from "../../institutions/components/PendingStaffInviteDialog";
import {
  AdminWorkspaceContext,
  activeMemberships,
  workspaceStorageKey,
} from "../context/AdminWorkspaceContext";
import { useQueryClient } from "@tanstack/react-query";
import { useDispatch } from "react-redux";
import { resetExam } from "../../../store/newExamSlice";
import "../styles/dashboard.css";
import "../styles/integrated-admin.css";

export default function DashboardPage() {
  const [collapsed, setCollapsed] = useState(false);
  const [user, setUser] = useState(null);
  const [access, setAccess] = useState(null);
  const [institutions, setInstitutions] = useState([]);
  const [institutionId, setInstitutionIdState] = useState("");
  const [institutionBranding, setInstitutionBranding] = useState(null);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const cache = useQueryClient();
  const dispatch = useDispatch();

  const refreshAccess = useCallback(
    async (userId, retainSelection = true) => {
      if (isDemo) return;
      const nextAccess = await getInstitutionAccess();
      const memberships = activeMemberships(nextAccess);
      const ownerInstitutions = nextAccess.platform_owner
        ? await listPlatformInstitutions()
        : [];
      const options = nextAccess.platform_owner
        ? ownerInstitutions.map((i) => ({
            id: i.id,
            name: i.name,
            code: i.code,
            status: i.status,
          }))
        : memberships.map((i) => ({
            id: i.institution_id,
            name: i.institution_name,
            code: i.institution_code,
            status: i.institution_status,
          }));
      setAccess(nextAccess);
      setInstitutions(options);
      const preferred = retainSelection
        ? sessionStorage.getItem(workspaceStorageKey(userId))
        : null;
      const picked =
        options.find((i) => i.id === preferred) ||
        options.find((i) =>
          memberships.some((m) => m.institution_id === i.id),
        ) ||
        options[0];
      const selectedId = picked?.id || "";
      setInstitutionIdState(selectedId);
      if (selectedId)
        sessionStorage.setItem(workspaceStorageKey(userId), selectedId);
      if (!nextAccess.platform_owner && memberships.length === 0) {
        navigate("/institution/apply", { replace: true });
      }
    },
    [navigate],
  );

  useEffect(() => {
    let mounted = true;
    async function initialize() {
      const result = await supabase.auth.getUser();
      if (!mounted) return;
      if (!result.data?.user || result.error) {
        navigate("/admin-login", { replace: true });
        return;
      }
      setUser(result.data.user);
      if (!isDemo) await refreshAccess(result.data.user.id);
    }
    initialize().catch((e) => {
      if (mounted)
        setError(e.message || "Could not verify your institution membership.");
    });
    const { data } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        cache.clear();
        navigate("/admin-login", { replace: true });
      }
    });
    return () => {
      mounted = false;
      data.subscription.unsubscribe();
    };
  }, [navigate, cache, refreshAccess]);

  // Reload branding whenever the institution changes (also updated after saving settings).
  const refreshBranding = useCallback(async () => {
    if (isDemo || !institutionId) {
      setInstitutionBranding(null);
      return;
    }
    setInstitutionBranding(null);
    try {
      const brand = await getInstitutionBranding(institutionId);
      setInstitutionBranding(brand);
    } catch {
      setInstitutionBranding(null);
    }
  }, [institutionId]);

  useEffect(() => {
    refreshBranding();
  }, [refreshBranding]);

  const membership = useMemo(
    () =>
      (access?.institutions || []).find(
        (i) =>
          i.institution_id === institutionId &&
          i.member_status === "active" &&
          i.institution_status === "active",
      ),
    [access, institutionId],
  );
  const selectedInstitution = institutions.find((i) => i.id === institutionId);
  const isOwner = Boolean(access?.platform_owner);
  const canUseExams = isDemo || Boolean(membership);
  const isSuperAdmin = membership?.role === "institution_super_admin";
  const canManageTeam = !isDemo && (isOwner || isSuperAdmin);

  const setInstitutionId = useCallback(
    (nextId) => {
      if (!institutions.some((i) => i.id === nextId) || !user) return;
      setInstitutionIdState(nextId);
      sessionStorage.setItem(workspaceStorageKey(user.id), nextId);
      // Erase cached institution-specific records on every tenant switch.
      cache.clear();
      dispatch(resetExam());
    },
    [institutions, user, cache, dispatch],
  );

  async function logout() {
    await supabase.auth.signOut();
    cache.clear();
    navigate("/", { replace: true });
  }
  if (error)
    return (
      <div className="portal-message" role="alert">
        <p>{error}</p>
        <button onClick={logout}>Sign out</button>
      </div>
    );
  if (!user || (!isDemo && !access))
    return (
      <div className="portal-message">Opening your Qualify dashboard…</div>
    );

  const context = {
    user,
    access,
    institutions,
    institutionId,
    selectedInstitution,
    membership,
    isOwner,
    isSuperAdmin,
    canUseExams,
    canManageTeam,
    setInstitutionId,
    institutionBranding,
    refreshBranding,
    refreshUser: async () => {
      const { data } = await supabase.auth.getUser();
      if (data.user) setUser(data.user);
    },
    refreshWorkspace: () => refreshAccess(user.id),
  };
  const nav = [
    ...(canUseExams
      ? [
          ["exams", "Examinations", FiBook],
          ["question-bank", "Question bank", FiLayers],
          ["calendar", "Calendar", FiCalendar],
          ["reports", "Reports", FiBarChart2],
        ]
      : []),
    ...(canManageTeam ? [["team", "Staff management", FiUsers]] : []),
    ...(isOwner ? [["institutions", "Institutions", FiGrid]] : []),
    ["settings", "Settings", FiSettings],
  ];

  return (
    <AdminWorkspaceContext.Provider value={context}>
      {!isDemo && <PendingStaffInviteDialog />}
      <div
        className={`admin-dashboard ${collapsed ? "sidebar-collapsed" : ""}`}
      >
        <aside className="sidebar">
          <div className="sidebar-header">
            <NavLink to="/" className="logo">
              QUALIFY
            </NavLink>
            <button
              aria-label="Toggle navigation"
              className="toggle-btn"
              onClick={() => setCollapsed(!collapsed)}
            >
              <FiMenu />
            </button>
          </div>
          <nav className="nav-menu">
            {nav.map(([path, label, Icon]) => (
              <NavLink
                key={path}
                aria-label={label}
                to={`/admin/${path}`}
                className={({ isActive }) =>
                  `nav-item ${isActive ? "active" : ""}`
                }
              >
                {createElement(Icon, { className: "nav-icon" })}
                <span className="nav-text">{label}</span>
              </NavLink>
            ))}
          </nav>
          <div className="sidebar-footer">
            <button
              aria-label="Sign out"
              className="logout-btn"
              onClick={logout}
            >
              <FiLogOut className="nav-icon" />
              <span>Sign out</span>
            </button>
          </div>
        </aside>
        <main className="main-content">
          <header className="top-nav workspace-top-nav">
            <div className="integrated-top-left workspace-heading">
              <InstitutionBrand
                name={
                  institutionBranding?.name ||
                  selectedInstitution?.name ||
                  (isDemo ? "Demo institution" : "Institution workspace")
                }
                logoPath={institutionBranding?.logo_path}
                subtitle="Examination Portal"
              />
            </div>
            <div className="user-profile workspace-profile">
              <span className="integrated-role">
                <span className="workspace-role-dot" />
                {isOwner
                  ? "Platform Owner"
                  : isSuperAdmin
                    ? "Super Admin"
                    : "Staff Admin"}
              </span>
              <span className="avatar workspace-avatar">
                {(user.user_metadata?.full_name || user.email || "A")
                  .charAt(0)
                  .toUpperCase()}
              </span>
              <span className="workspace-user-name">
                {user.user_metadata?.full_name || user.email}
              </span>
            </div>
          </header>
          <div className="content-wrapper">
            {isDemo && (
              <div className="demo-banner">
                <span>
                  <strong>Live demo</strong> · Sample data, saved in this
                  browser
                </span>
                <NavLink to="/exams/demo-active/student/demo-student">
                  Try student view →
                </NavLink>
              </div>
            )}
            {!isDemo && !selectedInstitution && isOwner && (
              <div className="ops-panel">
                Create your first institution from the Institutions tab.
              </div>
            )}
            <Outlet />
          </div>
        </main>
      </div>
    </AdminWorkspaceContext.Provider>
  );
}
