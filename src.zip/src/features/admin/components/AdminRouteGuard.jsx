import { Navigate } from 'react-router-dom';
import { useAdminWorkspace } from '../context/AdminWorkspaceContext';

const accessByPermission = {
  exams: ({ canUseExams }) => canUseExams,
  institutionAdmin: ({ isOwner, isSuperAdmin }) => isOwner || isSuperAdmin,
  platformOwner: ({ isOwner }) => isOwner,
};

export default function AdminRouteGuard({ permission, children }) {
  const workspace = useAdminWorkspace();
  const canAccess = accessByPermission[permission]?.(workspace) ?? false;

  if (canAccess) return children;

  const destination = workspace.canUseExams
    ? '/admin/exams'
    : workspace.isOwner
      ? '/admin/institutions'
      : '/institution/apply';

  return <Navigate to={destination} replace />;
}
