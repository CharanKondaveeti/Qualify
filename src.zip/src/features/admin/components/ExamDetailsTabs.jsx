import { useState } from "react";
import { FiCheck, FiEdit2, FiLink, FiTrash2, FiX } from "react-icons/fi";
import { useQueryClient } from "@tanstack/react-query";
import QuestionList from "../../questions/components/QuestionList";
import QuestionTable from "../../questions/components/QuestionTable";
import StudentTable from "../../reports/components/StudentTable";
import { editQuestionInSupabase, updateStudentInSupabase, deleteStudentFromSupabase } from "../../../services/adminService";
import { adminIssueLink, studentLink } from "../../../services/secureExamService";
import "../styles/exam-details-tabs.css";

export default function ExamDetailsTabs({
  students, studentsLoading = false, questions, exam, passMark, setPassMark, mode = "questions",
}) {
  const cache = useQueryClient();
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState({ name: "", email: "", rollNo: "" });
  const [search, setSearch] = useState("");
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const upcoming = exam.exam_status === "upcoming";

  const visibleStudents = students.filter((student) =>
    `${student.student_name || ""} ${student.roll_no || ""} ${student.email || ""}`
      .toLowerCase().includes(search.trim().toLowerCase()),
  );

  function beginEdit(student) {
    if (!upcoming) return;
    setError("");
    setMessage("");
    setEditingId(student.student_report_id);
    setForm({
      name: student.student_name || "",
      email: student.email || "",
      rollNo: student.roll_no || "",
    });
  }

  async function saveStudent(id) {
    if (!upcoming || busyId) return;
    if (!form.name.trim() || !form.email.trim() || !form.rollNo.trim()) {
      setError("Name, email and hall ticket number are required.");
      return;
    }
    setBusyId(id);
    setError("");
    setMessage("");
    try {
      await updateStudentInSupabase(id, {
        student_name: form.name.trim(),
        email: form.email.trim(),
        roll_no: form.rollNo.trim(),
      });
      setEditingId(null);
      await cache.invalidateQueries({ queryKey: ["students-report", exam.exam_id] });
      setMessage("Student registration updated.");
    } catch (err) {
      setError(err.message || "Unable to update registration.");
    } finally {
      setBusyId(null);
    }
  }

  async function deleteStudent(student) {
    if (!upcoming || busyId) return;
    if (!window.confirm(`Delete registration for ${student.student_name}? This cannot be undone.`)) return;
    setBusyId(student.student_report_id);
    setError("");
    setMessage("");
    try {
      await deleteStudentFromSupabase(student.student_report_id);
      await cache.invalidateQueries({ queryKey: ["students-report", exam.exam_id] });
      setMessage("Student registration removed.");
    } catch (err) {
      setError(err.message || "Unable to delete registration.");
    } finally {
      setBusyId(null);
    }
  }

  async function renewLink(student) {
    if (!upcoming || busyId) return;
    if (!window.confirm(`Replace the private exam link for ${student.student_name}? Their old link will stop working.`)) return;
    setBusyId(student.student_report_id);
    setError("");
    setMessage("");
    try {
      const row = await adminIssueLink(student.student_report_id);
      const url = studentLink(exam.exam_id, row.student_report_id, row.access_token);
      try {
        await navigator.clipboard.writeText(url);
        setMessage("New private link copied. Share it securely; the old link is invalid.");
      } catch {
        window.prompt("Copy this new private link now (it will not be shown again):", url);
        setMessage("New link issued. The previous one is invalid.");
      }
    } catch (err) {
      setError(err.message || "Unable to issue a new link.");
    } finally {
      setBusyId(null);
    }
  }

  async function updateQuestion(question) {
    if (!upcoming) return;
    setError("");
    try {
      await editQuestionInSupabase(question);
      await cache.invalidateQueries({ queryKey: ["questions", exam.exam_id] });
    } catch (err) {
      setError(err.message || "Unable to update question.");
    }
  }

  if (mode === "questions") {
    return (
      <div className="upcoming-exam-details">
        {error && <p className="ops-error" role="alert">{error}</p>}
        {upcoming ? (
          <div className="questions-section">
            <QuestionList questions={questions} onUpdate={updateQuestion} examId={exam.exam_id} exam={exam} />
          </div>
        ) : (
          <>
            <p className="qualify-registration-help">Questions are read-only once the exam has started.</p>
            <QuestionTable questions={questions} />
          </>
        )}
      </div>
    );
  }

  if (mode === "results") {
    return exam.exam_status === "completed" ? (
      <StudentTable students={students} passMark={passMark} setPassMark={setPassMark}
        examId={exam.exam_id} exam={exam} />
    ) : null;
  }

  // Upcoming-only editing. Active and completed student monitoring is handled by ExamOperations.
  if (!upcoming) return null;

  return (
    <div className="qualify-registration-list">
      <div className="qualify-registration-list__header">
        <div>
          <h2>Registered students <span>({students.length})</span></h2>
          <p>Review and edit registrations before the exam starts.</p>
        </div>
        <input type="search" aria-label="Search registered students"
          value={search} onChange={(event) => setSearch(event.target.value)}
          placeholder="Search name, hall ticket or email" />
      </div>

      {error && <p role="alert" className="ops-error">{error}</p>}
      {message && <p role="status" className="ops-info">{message}</p>}

      {studentsLoading ? (
        <div className="qualify-registration-empty" role="status">Loading registrations…</div>
      ) : !students.length ? (
        <div className="qualify-registration-empty">
          <strong>No students registered yet</strong>
          <p>Share the registration link above or use Bulk registration below to add students.</p>
        </div>
      ) : (
        <div className="qualify-registration-list__scroll" role="region"
          aria-label="Registered students table" tabIndex={0}>
          <table className="students-table">
            <thead>
              <tr>
                <th>Full name</th><th>Hall ticket</th><th>Email</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {visibleStudents.map((student) => {
                const id = student.student_report_id;
                const editing = editingId === id;
                const disabled = Boolean(busyId);
                return (
                  <tr key={id}>
                    {editing ? (
                      <>
                        <td><input autoFocus aria-label="Student full name" value={form.name} required
                          onChange={(e) => setForm({ ...form, name: e.target.value })} /></td>
                        <td><input aria-label="Hall ticket" value={form.rollNo} required
                          onChange={(e) => setForm({ ...form, rollNo: e.target.value })} /></td>
                        <td><input aria-label="Student email" type="email" value={form.email} required
                          onChange={(e) => setForm({ ...form, email: e.target.value })} /></td>
                        <td><div className="qualify-registration-list__buttons">
                          <button type="button" disabled={disabled} onClick={() => saveStudent(id)} title="Save changes" aria-label="Save changes"><FiCheck /></button>
                          <button type="button" disabled={disabled} onClick={() => setEditingId(null)} title="Cancel" aria-label="Cancel edit"><FiX /></button>
                        </div></td>
                      </>
                    ) : (
                      <>
                        <td>{student.student_name}</td>
                        <td>{student.roll_no}</td>
                        <td>{student.email}</td>
                        <td><div className="qualify-registration-list__buttons">
                          <button type="button" disabled={disabled} onClick={() => beginEdit(student)} title="Edit registration" aria-label={`Edit ${student.student_name}`}><FiEdit2 /></button>
                          <button type="button" disabled={disabled} onClick={() => renewLink(student)} title="Replace private link" aria-label={`New private link for ${student.student_name}`}><FiLink /></button>
                          <button type="button" disabled={disabled} className="qualify-registration-list__danger" onClick={() => deleteStudent(student)} title="Delete registration" aria-label={`Delete ${student.student_name}`}><FiTrash2 /></button>
                        </div></td>
                      </>
                    )}
                  </tr>
                );
              })}
              {!visibleStudents.length && (
                <tr><td colSpan={4}>No registrations match your search.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
