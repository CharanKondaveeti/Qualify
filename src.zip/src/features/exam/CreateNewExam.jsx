import React, { useEffect, useState } from "react";
import Papa from "papaparse";
import { FiUpload, FiLoader, FiArrowLeft, FiPlus } from "react-icons/fi";
import { useNavigate } from "react-router-dom";
import "./css/createNewExam.css";
import PreviewQuestions from "../../ui/PreviewQuestions";
import {
  createExamInSupabase,
  createQuestionsInSupabase,
} from "../../services/admin";
import supabase from "../../services/supabase";
import { useDispatch, useSelector } from "react-redux";
import { setExamDetails } from "../../store/newExamSlice";
import { setQuestionsR } from "../../store/questionSlice";
import { useForm } from "react-hook-form";
import dayjs from "dayjs";

const CreateNewExam = () => {
  const dispatch = useDispatch();
  const newExamStore = useSelector((state) => state.newExam.newExam);
  const questions = useSelector((state) => state.questions.questions);
  const [isLoading, setIsLoading] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [questionError, setQuestionError] = useState("");
  const [endTime, setEndTime] = useState("");
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    defaultValues: {
      name: "",
      course: "",
      date: "",
      time: "",
      duration: "",
      totalMarks: "",
    },
  });

  const parseCSV = (file) => {
    setIsLoading(true);
    setQuestionError(""); // Clear previous error

    Papa.parse(file, {
      header: true,
      complete: (results) => {
        const parsed = results.data
          .filter((q) => q.question)
          .map((q, i) => ({
            question_id: Date.now() + i,
            question_text: q.question || "",
            options: [q.option1, q.option2, q.option3, q.option4].filter(
              Boolean
            ),
            correct_option: parseInt(q.correctAnswer) || 0,
            marks: parseInt(q.marks) || 1,
          }))
          .filter((q) => q.options.length > 0);

        if (parsed.length === 0) {
          setQuestionError("CSV must contain at least one valid question.");
        }

        dispatch(setQuestionsR(parsed));
        setIsLoading(false);
      },
      error: () => {
        alert("Error parsing CSV file");
        setIsLoading(false);
      },
    });
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const isCSV = file.type === "text/csv" || file.name.endsWith(".csv");

    if (isCSV) {
      parseCSV(file);
    } else {
      alert("Only CSV files are supported.");
    }
  };

  const createExam = async (formData) => {
    if (questions.length === 0) {
      setQuestionError("Please upload at least one question.");
      return;
    }

    try {
      dispatch(setExamDetails(formData));

      const {
        data: { user },
        error: authError,
      } = await supabase.auth.getUser();

      if (authError || !user) {
        alert("Unable to get user. Please login again.");
        return;
      }

      const dateTimeStr = `${formData.date}T${formData.time}`;
      const scheduledDate = new Date(dateTimeStr);

      const examData = {
        title: formData.name,
        course: formData.course,
        status: "upcoming",
        scheduled_date: scheduledDate.toISOString(),
        duration_minutes: parseInt(formData.duration),
        total_marks: parseInt(formData.totalMarks),
        created_by: user.id,
        total_questions: questions.length,
      };

      const examId = await createExamInSupabase(examData);

      const questionsWithExamId = questions.map(({ question_id, ...q }) => ({
        ...q,
        exam_id: examId[0]?.exam_id,
      }));

      await createQuestionsInSupabase(questionsWithExamId);

      alert("Exam and questions created successfully!");
      reset();
      dispatch(setExamDetails({}));
      setQuestionError("");
      navigate("/admin/exams");
    } catch (error) {
      console.error("Error creating exam and questions:", error);
      alert("Something went wrong. Please try again.");
    }
  };

  const formLabels = [
    {
      label: "Exam Name",
      type: "text",
      field: "name",
    },
    {
      label: "Course",
      type: "text",
      field: "course",
    },
    {
      label: "Exam Date",
      type: "date",
      field: "date",
    },
    {
      label: "Exam Time",
      type: "time",
      field: "time",
    },
    {
      label: "Duration (Minutes)",
      type: "number",
      field: "duration",
      min: 1,
    },
    {
      label: "Total Marks",
      type: "number",
      field: "totalMarks",
      min: 1,
    },
  ];
  useEffect(() => {
    const watchFields = newExamStore;
    const { date, time, duration } = watchFields;

    if (date && time && duration) {
      const start = new Date(`${date}T${time}`);
      const end = new Date(start.getTime() + duration * 60000); // Add duration in ms
      const formatted = end.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });
      setEndTime(formatted);
    } else {
      setEndTime("");
    }
  }, [newExamStore.date, newExamStore.time, newExamStore.duration]);
  return (
    <div className="create-exam-form">
      <div className="form-header">
        <button onClick={() => navigate(-1)}>
          <FiArrowLeft />
        </button>
        <h4>Create New Exam</h4>
      </div>

      <form className="form-grid" onSubmit={handleSubmit(createExam)}>
        {formLabels.map(({ label, type, field, min }) => (
          <div className="form-group" key={field}>
            <label>{label}</label>
            <input
              type={type}
              {...register(field, {
                required: `${label} is required`,
                min: min
                  ? { value: min, message: `Minimum is ${min}` }
                  : undefined,
              })}
            />
            {errors[field] && (
              <p className="error-text">{errors[field].message}</p>
            )}
          </div>
        ))}

        <FileUpload
          handleFileUpload={handleFileUpload}
          isLoading={isLoading}
          questionError={questionError}
        />

        <div className="form-actions">
          <button
            className="add-question-btn"
            type="button"
            onClick={() => setIsAddModalOpen(true)}
          >
            <FiPlus /> Add New Question
          </button>
          <button type="submit" className="create-exam-btn">
            Create Exam
          </button>
        </div>

        <div className="preview-section">
          <PreviewQuestions
            setIsAddModalOpen={setIsAddModalOpen}
            isAddModalOpen={isAddModalOpen}
          />
        </div>
      </form>
    </div>
  );
};

function FileUpload({ handleFileUpload, isLoading, questionError }) {
  return (
    <div className="form-group">
      <label>Upload Questions *</label>
      <div className="upload-area">
        <label className="upload-btn">
          <FiUpload />
          Choose CSV File
          <input
            type="file"
            accept=".csv"
            onChange={handleFileUpload}
            style={{ display: "none" }}
          />
        </label>
        <p className="upload-text">or drag and drop file here</p>
        {isLoading && (
          <div className="loading-indicator">
            <FiLoader className="spinner" />
            <span>Processing file...</span>
          </div>
        )}
      </div>
      {questionError && <p className="error-text">{questionError}</p>}
    </div>
  );
}

export default CreateNewExam;
