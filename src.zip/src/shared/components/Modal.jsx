import "../styles/modal.css";
import { FiX } from "react-icons/fi";

function Modal({ modal, confirmSubmit, closeModal, isSubmitting }) {
  return (
    modal?.show && (
      <div className="modal-overlay">
        <div role="dialog" aria-modal="true" aria-label={modal.title} className={`modal-container ${modal.type}`}>
          <div className="modal-header">
            <h3>{modal.title}</h3>
            {modal.type !== "submit" && (
              <button onClick={closeModal} className="modal-close">
                <FiX />
              </button>
            )}
          </div>

          <div className="modal-body">
            <p>{modal.message}</p>
          </div>

          <div className="modal-footer">
            {modal.type === "submit" ? (
              <>
                <button
                  onClick={confirmSubmit}
                  className="modal-confirm"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <div className="button-spinner">
                      <div className="spinner" />
                      <span>Submitting...</span>
                    </div>
                  ) : (
                    "Confirm"
                  )}
                </button>

                <button
                  onClick={closeModal}
                  className="modal-cancel"
                  disabled={isSubmitting}
                >
                  Cancel
                </button>
              </>
            ) : (
              <button onClick={closeModal} className="modal-ok">
                OK
              </button>
            )}
          </div>
        </div>
      </div>
    )
  );
}

export default Modal;
