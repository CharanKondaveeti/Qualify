import "../styles/blur-loader.css";

const BlurLoader = () => (
  <div className="blur-loader-overlay">
    <div className="loader">Submitting Exam...</div>
  </div>
);

export default BlurLoader;
