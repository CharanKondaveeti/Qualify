import '../styles/exam-loader.css';

function Loader() {
  return (
    <div className="loading-placeholder">
      <div className="loading-animation"></div>
    </div>
  );
}

export default Loader;